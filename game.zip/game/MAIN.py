import pygame
import os


pygame.init()

# SCREEN SIZE
SCREEN_WIDTH = 900
SCREEN_HEIGTH = 500
# TEMP GREEN BACKGROUND
BG = (144, 201, 120)
# TEMP GROUND
RED = (255, 0, 0)

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGTH))
pygame.display.set_caption('game name ?????')

# SETTING THE FPS FOR THE SCREEN
clock = pygame.time.Clock()
FPS = 60

# GAME VARIABLES
GRAVITY = 0.75

# PLAYER ACTION VARIABLES
moving_left = False
moving_right = False
#jumpCount = 10 --- FUTURE


# DRAWING THE SCREEN
def draw_bg():
   screen.fill(BG)
   pygame.draw.line(screen, RED, (0, 300), (SCREEN_WIDTH, 300))




class Soldier(pygame.sprite.Sprite):
    def __init__(self, x, y, scale, speed):
        pygame.sprite.Sprite.__init__(self)
        self.live = True
        self.speed = speed
        self.direction = 1
        self.jump = False
        self.in_air = True
        self.vel_y = 0
        self.flip = False
        self.animation_list = []
        self.frame_index = 0
        self.action = 0
        self.update_time = pygame.time.get_ticks()

        animation_types = ['IDLE', 'RUNNING', 'JUMPING']
        for animation in animation_types:
            temp_list = []
            num_of_frames = len(os.listdir(f'PLAYERACTIONS/{animation}'))
            for i in range(num_of_frames):
                img = pygame.image.load(f'PLAYERACTIONS/{animation}/{i}.png')
                img = pygame.transform.scale(img, (int(img.get_width() * scale), int(img.get_height() * scale)))
                temp_list.append(img)
            self.animation_list.append(temp_list)
        
        self.image = self.animation_list[self.action][self.frame_index]
        self.rect = self.image.get_rect()
        self.rect.center = (x,y)

    # MOVEMENT 
    def moving(self, moving_left, moving_right):
        dx = 0
        dy = 0

        if moving_left:
            dx = -self.speed
            self.flip = True
            self.direction = -1

        if moving_right:
            dx = self.speed
            self.flip = False
            self.direction = 1

        if self.jump == True and self.in_air == False:
            self.vel_y = -13
            self.jump = False
            self.in_air = True
        # GRAVITY
        self.vel_y += GRAVITY
        if self.vel_y > 10:
            self.vel_y 
        dy += self.vel_y

        #TEMP
        if self.rect.bottom + dy > 300:
            dy = 300 - self.rect.bottom
            self.in_air = False

        self.rect.x += dx
        self.rect.y += dy

    def update_animation(self):
        ANIMATION_COOLDOWN = 100
        self.image = self.animation_list[self.action][self.frame_index]
        if pygame.time.get_ticks() - self.update_time > ANIMATION_COOLDOWN:
            self.update_time = pygame.time.get_ticks()
            self.frame_index += 1
        if self.frame_index >= len(self.animation_list[self.action]):
            self.frame_index = 0

    def update_action(self, new_action):
        if new_action != self.action:
            self.action = new_action
            self.frame_index = 0
            self.update_time = pygame.time.get_ticks()


    # DRAWING THE CHARACTER AND FLIPPING THE IMAGE 
    def draw(self):
        screen.blit(pygame.transform.flip(self.image, self.flip, False) , self.rect)

# SETTING PLAYER TO SOLDIER CLASS WITH ARGS (TEMP CORDINATES FOR CHARACTER, TEMP IMAGE SCALE, TEMP SPEED OF CHARACTER MOVEMENT)
player = Soldier(100, 100, 2, 5)

# MAIN
run = True
while run:
    clock.tick(FPS)
    draw_bg()
    player.update_animation()
    player.draw()

    if player.live: 
        if player.in_air:
            # JUMP = 2
            player.update_action(2)
        elif moving_left or moving_right:
        # RUNNING = 1
            player.update_action(1)
        else:
        # IDLE = 0
            player.update_action(0)

    player.moving(moving_left, moving_right)

    # ASSINGING KEYS MOVEMENTS 
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_a:
                moving_left = True
            if event.key == pygame.K_d:
                moving_right = True
            if event.key == pygame.K_SPACE and player.live:
                player.jump = True
            if event.key == pygame.K_ESCAPE:
                run = False
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_a:
                moving_left = False
            if event.key == pygame.K_d:
                moving_right = False

    pygame.display.update()


pygame.quit()
