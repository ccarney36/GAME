import pygame


# future way to edit each level